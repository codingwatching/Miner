minetest.register_craftitem("m_core:stick", {
    description = "Stick",
    inventory_image = "stick_texture.png"
})