Miner is cool like Crafter!
Textures from https://content.minetest.net/packages/eyekay/alt_tp/